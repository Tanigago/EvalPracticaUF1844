const host = "https://web-develop-react-express-chat.herokuapp.com"
const htmlGetUsers = document.querySelector("#getUsers");
const htmlPostUsers = document.querySelector("#postUsers");
const htmlUpdateButton = document.querySelector("#updateButton");
const htmlUpdateConsoleButton = document.querySelector("#updateConsoleButton");
const htmlTokenButton = document.querySelector("#tokenButton");
const htmlMsgButton = document.querySelector("#htmlMsgButton");

//Aquí actualizo la lista de usuarios.
async function get(url) {
    const response = await fetch(url);
    const data = await response.json();
    htmlGetUsers.innerText = JSON.stringify(data);
}

const data = JSON.stringify({userName:"Riego", password:"123.456"});
const token = authToken("1649058094422","123.456");

//Aquí me logueo.
async function post(url, data) {
    const response = await fetch(
        url,
        {
            method: 'POST',
            body: data,
            headers: {
                "Content-Type": "application/json",
            }
        }
    );
    const responseData = await response.json();
    console.log(responseData);
}

function authToken(id, secret) {
    const authToken = `${id}:${secret}`;
    const base64token = btoa(authToken);
    return `Basic ${base64token}`;
}

//Aquí actualizo la lista de mensajes.
async function authGet(url, token) {
    const response = await fetch(
        url,
        { 
            headers: {
                Authorization: token
            }
        }
    );
    const data = await response.json();
    console.log(data);
}

//Aquí mando el mensaje.
async function authPost(url, token, data) {
    data = JSON.stringify({content: "Fémur"});
    const response = await fetch(
        url,
        {
            method: "POST",
            body: data,
            headers: {
                "Content-Type": "application/json",
                Authorization: token
            }
        }
    );
    const responseData = await response.json();
    return responseData;
}

function updateButtonClickHandler() {
    get(host+"/users/");
}

function updateConsoleButtonHandler () {
    post(host+"/login/", data);
}

function getMsgButtonHandler () {
    authGet(host+"/messages/", token);
}

function postMsgButtonHandler() {
    authPost(host+"/message/", token, data);
}

htmlUpdateButton.addEventListener("click", updateButtonClickHandler)
htmlUpdateConsoleButton.addEventListener("click", updateConsoleButtonHandler)
htmlTokenButton.addEventListener("click", getMsgButtonHandler)
htmlMsgButton.addEventListener("click", postMsgButtonHandler)



