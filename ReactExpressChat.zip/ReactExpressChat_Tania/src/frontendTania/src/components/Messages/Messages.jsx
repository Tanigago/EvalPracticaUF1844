import { useEffect, useRef, useState } from "react"
import '../../App.css';


function Messages({ id, password }) {
    const host = "https://web-develop-react-express-chat.herokuapp.com"
    const [text, setText] = useState("");
    const timer = useRef(0);

    function authToken(id, secret) {
        const authToken = `${id}:${secret}`;
        const base64token = btoa(authToken);
        return `Basic ${base64token}`;
    }

    function inputHandler(ev) {
        setText(ev.target.value)
    }
    async function authGet(url, token) {
        const response = await fetch(
            url,
            {
                headers: {
                    Authorization: token
                }
            }
        );
        const data = await response.text();
        setText(data);
    }

    const token = authToken(id, password);

    function getMsgHandler() {
        authGet(host + "/messages/", token);
    }

useEffect(
    () => {
        if (timer.current != 0) clearInterval(timer.current);
        timer.current = setInterval(getMsgHandler, 3000);
    },
    []
)

return (
    <div className="sitioChat">
        <textarea className="areatexto" value={text} onChange={inputHandler} />
    </div>

)
}

export default Messages