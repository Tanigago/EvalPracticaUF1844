import { useState } from 'react'
import '../../App.css';


function SendMessage ({id, password}){
    const host = "https://web-develop-react-express-chat.herokuapp.com"
    const [text, setText] = useState("");
    const data = JSON.stringify({content: text});

    function authToken(id, secret) {
        const authToken = `${id}:${secret}`;
        const base64token = btoa(authToken);
        return `Basic ${base64token}`;
    }

    const token = authToken(id, password);

    async function authPost(url, token, data) {
        const response = await fetch(
            url,
            {
                method: "POST",
                body: data,
                headers: {
                    "Content-Type": "application/json",
                    Authorization: token
                }
            }
        );
        const responseData = await response.json();
        return responseData;
    }
    function changeTextHandler(ev){
        setText(ev.target.value)
    }

    function sendMsgHandler() {
        authPost(host+"/message/", token, data);
    }

    return (
        <div className="sitioSend">
            <input className='cajaTexto' type="text" value={text} onChange={changeTextHandler}/>
            <button className='botonEnviar' onClick={sendMsgHandler}>Enviar</button>
        </div>
    )
}

export default SendMessage