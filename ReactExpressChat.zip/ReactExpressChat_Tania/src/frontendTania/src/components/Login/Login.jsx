import { useState } from "react";
import '../../App.css';

function Login() {
    const host = "https://web-develop-react-express-chat.herokuapp.com"
    const [nombreusuario, setNombreusuario] = useState("")
    const [contrasena, setContrasena] = useState("")

    async function post(url, data) {
        const response = await fetch(
            url,
            {
                method: 'POST',
                body: data,
                headers: {
                    "Content-Type": "application/json",
                }
            }
        );
        const responseData = await response.json();
        console.log(responseData);
    }

    function changeUsuarioHandler(ev) {
        setNombreusuario(ev.target.value)
    }
    function changePassHandler(ev) {
        setContrasena(ev.target.value)
    }

    function loginButtonHandler() {
        const data = JSON.stringify({ userName: nombreusuario, password: contrasena });
        post(host + "/login/", data);
        console.log(data);
    }

    return (
        <div className="sitioLogin">
            <div>
                <label>Username:</label><br />
                <input type="text" value={nombreusuario} id="username" name="username" onChange={changeUsuarioHandler} /><br />
                <label>Password:</label><br />
                <input type="password" value={contrasena} id="pwd" name="pwd" onChange={changePassHandler} />
            </div>
            <button onClick={loginButtonHandler} id="loginButtonHandler">Login</button>
        </div>

    );
}

export default Login