import './App.css';
import Login from './components/Login/Login';
import Messages from './components/Messages/Messages';
import SendMessage from './components/Send Message/SendMenssage';

function App() {

  return (
    <>
      <Login/>
      <Messages id ="1650958599623" password = "123.456"/>
      <SendMessage id ="1650958599623" password = "123.456"/>
    </>
  );
}

export default App;
