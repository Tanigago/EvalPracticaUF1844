GUÍA PARA EL USO DEL CHAT.

1. Con ayuda del terminal sitúate en "src/frontedTania/".

2. Inicia el comando npm start y espera.

3. Una vez en el navegador, abre la herramienta de consola e introduce un nombre de usuario y una contraseña.

4. Al hacer click en "Login" se mostrará el token en la consola, copia ese número y sustitúyelo en ambos "id" del archivo "App.js", cambia también la contraseña por la que hayas utlizado en el momento de hacer el Login.

5. Guarda los cambios y actualiza el navegador.

6. A continuación, podrás escribir el mensaje en el área de texto de la parte inferior, para enviar pulsa el botón "Enviar" y listo, ya estarás hablando solo en la corrección de los exámenes.

Buen día.